^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package generalik
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2015-10-12)
------------------

1.0.0 (2014-10-10)
------------------
* Support for building in fuerte
* Switched to using openrave_catkin
* Switched to finding OpenRAVE with find_package
* Contributors: Evan Shapiro, Michael Koval

0.0.1 (2014-05-22)
------------------
* Import from SVN
* Contributors: Dmitry Berenson
